'use strict';

/**
 * @ngdoc function
 * @name patManApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the patManApp
 */
 
 
 var obtdPats=[{}];
 var tabKey=0;
var app=angular.module('patManApp');
app.requires.push('angularCharts');
var obtdSymps = [];
var docList=[];
var defDocs=[];
var persona=0;

var modifier='John Doe';
app.directive("adminView", function() {
        return {
            restrict:"E",
            templateUrl: "/views/adminView.html"
        };
    });

app.directive("doctorView", function() {
        return {
            restrict:"E",
            templateUrl: "/views/doctorView.html"
        };
    });
  app.controller('MainCtrl', function ($http,$route,$scope,$rootScope) {
    this.awesomeThings = [
      
    ];
	//$scope.persona=1;
	$rootScope.user=modifier;
	if($rootScope.user=='ANOKUMAR')$scope.persona=0;
	else if($rootScope.user=='SHRANAND')$scope.persona=1;
	
	
	
	$http({
					url: 'http://hana01.dev.dci.local:8000/SaintResearch/SessionUser.xsjs',
					//method: "GET",
					
				})
				.then(function(response) {
						// success
						//$scope.MainCtrl.user=response.data
						//if($scope.MainCtrl.user=='SHRANAND'){$scope.MainCtrl.persona=1;}
						//obtdPats=response.data.d.results;
						//$scope.MainCtrl.user=response.data;
						
						
						
						if(tabKey==0){
						if(response.data=='SHRANAND'){alert("logged in as "+response.data);$rootScope.user=response.data;modifier=response.data;}
						else if(response.data=='ANOKUMAR'){alert("logged in as "+response.data);$rootScope.user=response.data;modifier=response.data;}
						else
						alert("Sorry, Not logged into HANA as privileged user.");
						
						//alert("Obtained logged user: "+((reponse.data.length<20)?JSON.stringify(response.data,null," "):"No Logon"));
						}
						
				}, 
				function(response) { // optional
						// failed
						alert("Could not obtain login details.");
				});
	
	
		 
		
  });
  
  app.controller('AdminController', function($http,$route){
  $http({
					url: 'http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/admin/?$format=json',
					method: "GET",
					
				})
				.then(function(response) {
						// success
						
						obtdPats=response.data.d.results;
						
						if(tabKey==0){/*alert("success"+JSON.stringify(obtdPats,null," "));*/tabKey=1;$route.reload();}
						
						
				}, 
				function(response) { // optional
						// failed
						alert("Initialization of Table from HANA Database failed. Please Log In Try Again.");
				});
				
			
				
	$http({
					url: 'http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/symptoms/?$format=json',
					method: "GET",
					
				})
				.then(function(response) {
						// success
						for(var i=0;i<response.data.d.results.length;i++)
						{obtdSymps[i]=response.data.d.results[i].symptom;}
						
						//alert("success obtaining symptoms"+JSON.stringify(obtdSymps,null," "));
						
						
				}, 
				function(response) { // optional
						// failed
						//alert("Initialization of Table from HANA Database failed. Please Log In Try Again.");
				});	

var obtdDocs=[];

				
			 //http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/doctors?$select=docName&$format=json
			$http({
					url: 'http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/docTab?$select=docName&$format=json',
					method: "GET",
					
				})
				.then(function(response) {
						// success
						for(var i=0;i<response.data.d.results.length;i++)
						{docList[i]=response.data.d.results[i].docName;
						defDocs[i]=response.data.d.results[i].docName;
						}
						
						//alert("success obtaining symptoms"+JSON.stringify(obtdSymps,null," "));
						
						
				}, 
				function(response) { // optional
						// failed
						//alert("Initialization of Table from HANA Database failed. Please Log In Try Again.");
				});	
				
				
				$http({
					url: 'http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/admin/?$format=json',
					method: "GET",
					
				})
				.then(function(response) {
						// success
						
						obtdPats=response.data.d.results;
						
						if(tabKey==0){alert("success"+JSON.stringify(obtdPats,null," "));tabKey=1;$route.reload();}
						
						
				}, 
				function(response) { // optional
						// failed
						//alert("Initialization of Table from HANA Database failed. Please Log In Try Again.");
				});
					
	
		
	
			
				
	
	
	
  
  });
  
  
  var patientList = [
		{'id':123,
		 'fname': 'Ramesh Srinivasan',
		 'phno': '8791010212',
		 'gender':'M',
		 'add': 'House, Street, Town, State',
		 'age': 34,
		 'enrollDate':1440058051543,
		 'email':'ramsri@abc.com',
		 'updateDate':1440058051543,
		 'docName':'NA',
		 'symptom': 'Cold' },
		{'id':456,
		 'fname': 'Sandhya Kumar',
		 'phno': '9374586758',
		 'gender':'F',
		 'add': 'House, Locality, District, State',
		 'age': 29,
		 'email':'sankum@abc.com',
		 'enrollDate':1440058051543,
		 'updateDate':1440058051543,
		 'docName':'Dr. Tarun',
		 'symptom': 'Swelling'},
		{'id':789,
		 'fname': 'Farooq M P',
		 'phno': '8594848594',
		 'gender':'M',
		 'add': 'Plot, Street, City, State',
		 'age': 22,
		 'email':'farmp@aabc.com',
		 'enrollDate':1440058051543,
		 'updateDate':1440058051543,
		 'docName':'Dr. Kiran',
		 'symptom': 'Migraine'}
	  ];
	  
	  
	  
	  var toSend = {'age':12,'name':'Shrey'};
	  
	  
var symptomList = ['Fever', 'Cold', 'Cough', 'Vomiting', 'Insomnia', 'Migraine', 'Swelling', 'Fracture', 'Laughing'];

	  
	  
	var currPat={};  
	var currTab=1;
	var isUpdate=0;
	  
  
  
  
	  app.controller('PatListCtrl', function ($scope,$route,$http,$window) {
	  $scope.alert=alert;
	  this.isUpdat=isUpdate;
	  $scope.patients = obtdPats;
	  //$scope.patients = patientList;
	  
	  
	  
	   $scope.updatePat = function(id){
	   
	   
			
			
			currPat={};
			isUpdate=1;
            currPat=obtdPats[id];
			
			
		

			
			//currPat=patientList[id];
			alert(JSON.stringify(currPat,null,"    "));
			currTab=2;
			isUpdate=1;
			$route.reload();
            

        };
		
		
		$scope.removePat = function(ind){
			
			
            var currPid=obtdPats[ind].pid.toString();
			//var currPid=patientList[ind].id.toString();
			alert("Remove from HANA patient with PID: " +currPid);
			$http({
					url: 'http://10.17.206.147:8080/rest/patient/deletePatient/'+currPid,
					method: "DELETE",
					//headers: {'Accept': 'application/json','Content-Type': 'application/json' },
					//data: currPid
					data: obtdPats[ind].pid
				})
				.then(function(response) {
						// success
						//alert("success"+JSON.stringify(response,null," "));
						alert("Successfully Deleted Patient");
						tabKey=0;
			
						obtdPats=[];
						$scope.patients=[];
						$window.location.reload();
						
				}, 
				function(response) { // optional
						// failed
						alert("Failed to Delete Patient");
						//alert("failed"+JSON.stringify(response,null," "));
				});
			
			
			/*
			tabKey=0;
			
			obtdPats=[];
			
			$window.location.reload();
			*/
            

        };
	  
	});
  
  
   app.controller("TabController", function($route) {
        this.tab = currTab;
		this.patient=currPat;

        this.isSet = function(checkTab) {
            return this.tab === checkTab;
        };

        this.setTab = function(setTab) {
            if(currTab==2&&setTab==1){ currPat = {};
			currTab=1;
			isUpdate=0;
			$route.reload();
			}
			else
			this.tab = setTab;
        };
    });
	
	
	app.controller("PatientController", function($scope,$route,$rootScope,$http,$window){
		//this.symptoms=symptomList;
		this.symptoms=obtdSymps;
		
		this.patient=currPat;
		$scope.patCtrl.obtdDocs=docList;
		$scope.patCtrl.obtdDocID=[];
		var docKey=0;
		//var tempDocs=[];
		
		$scope.updateDoc=function(){
		alert("docupdate");
		$scope.patCtrl.obtdDocs={};
		$scope.patCtrl.patient.docName= 'Suggesting a doctor for you.';
		
		
		
		$http({ //http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/doctors?$filter=symptom%20eq%20%27laughing%27&$select=docName&$format=json

					url: 'http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/doctors?$filter=symptom%20eq%20%27'+$scope.patCtrl.patient.symptom+'%27&$select=docName,did&$format=json',
					method: "GET",
					
				})
				.then(function(response) {
						// success
						for(var i=0;i<response.data.d.results.length;i++)
						{$scope.patCtrl.obtdDocs[i]=response.data.d.results[i].docName;$scope.patCtrl.obtdDocID[i]=response.data.d.results[i].did;}
						docKey=Math.floor(Math.random()*response.data.d.results.length);
						$scope.patCtrl.patient.docName=$scope.patCtrl.obtdDocs[docKey];
						$scope.patCtrl.patient.did=$scope.patCtrl.obtdDocID[docKey];
						//alert("success obtaining symptoms"+JSON.stringify($scope.patCtrl.patient.docName,null," "));
						//alert("Doctor IDS"+JSON.stringify($scope.patCtrl.obtdDocID,null," "));
						//=obtdDocs[Math.floor((Math.random() * response.data.d.results.length));];
						
				}, 
				function(response) { // optional
						// failed
						alert("Initialization of Table from HANA Database failed. Please Log In Try Again.");
				});			
	
		//this.obtdDocs=tempDocs;
		docList=$scope.patCtrl.obtdDocs;
		currTab=2;
		//$route.reload();
		
		
		};
		
		
		this.key=isUpdate;
		//var sympID1=this.symptoms.indexOf(this.patient.symptom);
        
		this.patient.updateDate=Date.now();
		this.patient.modifiedBy=$rootScope.user;
		//this.patient.docID=$scope.patCtrl.obtdDocID[docKey];
        this.addReview = function(){
			if(this.patient.docName==null||this.patient.docName==""){this.patient.docName="NA"}
			
			
			if(this.key==0)
			{//this.patient.ID=obtdPats.length;
			this.patient.enrollDate=Date.now();
			/*patients.Push(this.patient);*/
			this.patient.sid=this.symptoms.indexOf(this.patient.symptom);
			//alert("Symptoms OBTD"+this.symptoms);
			//alert("SympID"+this.patient.sid+"Symptom:"+this.patient.symptom);
			//this.patient.symptom=this.patient.symptoms[0];
			//alert("Sending: "+JSON.stringify(this.patient,null,"   "));
			/*
			var res = $http.post('10.17.206.134:8080/rest/patient/registerPatient',{'fname':'shrey'});
			
		res.success(function(data, status, headers, config) {
			$scope.message = data;
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	
		
		*/
		
		//alert(JSON.stringify(toSend,null," "));
				$http({
					url: 'http://10.17.206.147:8080/rest/patient/registerPatient/',
					method: "POST",
					headers: {'Accept': 'application/json','Content-Type': 'application/json' },
					data: this.patient
					/* data: this.patient */
				})
				.then(function(response) {
						// success
						//alert("success"+JSON.stringify(response,null," "));
						//this.patient={};
						currPat = {};
						currTab=1;
						isUpdate=0;
						obtdPats=[];
						$scope.patients=[];
						$window.location.reload();
						
						
				}, 
				function(response) { // optional
						// failed
						//alert("failed"+JSON.stringify(response,null," "));
				});
			
            }
			else{//update patient using odata sp here
			
			this.patient.sid=this.symptoms.indexOf(this.patient.symptom);
			this.toSendItem={};
			this.toSendItem.fname=this.patient.fname;
			this.toSendItem.age=this.patient.age;
			this.toSendItem.gender=this.patient.gender;
			this.toSendItem.phno=this.patient.phno;
			this.toSendItem.add=this.patient.add;
			this.toSendItem.sid=this.patient.sid;
			this.toSendItem.pid=this.patient.pid;
			
			//this.toSendItem.did=this.patient.did;
			//alert("Check for docs"+defDocs);
			var docID =defDocs.indexOf(this.patient.docName);
			//alert("Doctor is:"+docID.toString());
			this.toSendItem.did=docID;
			//alert(JSON.stringify(this.toSendItem,null," "));
				$http({
					url: 'http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/update_sp',
					method: "POST",
					headers: {'Accept': 'application/json','Content-Type': 'application/json' },
					data: this.toSendItem
					/* data: this.patient */
				})
				.then(function(response) {
						// success
						//alert("success"+JSON.stringify(response,null," "));
						//this.patient={};
						 currPat = {};
						currTab=1;
						isUpdate=0;
						$window.location.reload();
						
				}, 
				function(response) { // optional
						// failed
						//alert("failed"+JSON.stringify(response,null," "));
				});
			
			
			
			
			
			//alert(JSON.stringify(this.patient,null,"  "));
			
			
			}
           /*
			this.patient={};
			 currPat = {};
			currTab=1;
			isUpdate=0;
			$window.location.reload();
			*/

        };
		
				
    });
	
	
	app.controller('docCtrl', function ($scope,$http) {
	$scope.symps=[];
	$scope.counts=[];
	//$scope.currDoc='AllDoc';
	
					/*$scope.data1={
										  series: $scope.symps,
										  data: [{
											x: "Symptoms",
											y: $scope.counts,
											tooltip: "This is a tooltip"
										  }]
										}		
		*/
					$scope.updateChart=function(){
					
					var url1;
					if($scope.currDoc=='AllDoc'){url1='http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/table_data?$select=att_symptoms_symptom,count&$format=json';}
					else url1='http://hana01.dev.dci.local:8000/SaintResearch/model/services/admin.xsodata/table_data?$select=att_symptoms_symptom,count&$filter=did%20eq%20'+$scope.doctors.indexOf($scope.currDoc) +'&$format=json';
									$http({
							
					url:url1 ,
				
					method: "GET",
					headers: {'Accept': 'application/json','Content-Type': 'application/json' },
						//data: this.toSendItem
						/* data: this.patient */
					})
					.then(function(response) {
							// success
							//$scope.symps=[];
							//$scope.counts=[];
							for (var i=0;i<$scope.symps.length;i++){
							$scope.symps.pop();
							$scope.counts.pop();
							
							}
							
							//for (var i=0;i<$scope.data1.data.length-1;i++){
							//$scope.data1.data.pop();
							//$scope.counts.pop();
							
							//}
						/*
							$scope.data1={
										  series: $scope.symps,
										  data: [{
											x: "Symptoms",
											y: $scope.counts,
											tooltip: "This is a tooltip"
										  }]
										}	

						*/				
							//alert("success"+JSON.stringify(response,null," "));
							
							for(var i=0;i<response.data.d.results.length;i++){
							$scope.symps[i]=response.data.d.results[i].att_symptoms_symptom;
							$scope.counts[i]=response.data.d.results[i].count;
							
							
							//$scope.data1.data[i].x=response.data.d.results[i].att_symptoms_symptom;
							//$scope.data1.data[i].tooltip=response.data.d.results[i].att_symptoms_symptom;
							//$scope.data1.data[i].y=response.data.d.results[i].count;
							}
							//alert("Symptom list found: "+JSON.stringify(symps,null," "));
							
					}, 
					function(response) { // optional
							// failed
							alert("failed"+JSON.stringify(response,null," "));
					});

					
					
				};
	
	
					
				   //this.currDoc=docList[0];
				   $scope.chartType='bar';
				   //$scope.show='Helloorld';
				   $scope.doctors=docList;
				   this.currDoc=$scope.doctors[0];
				   $scope.data={
										  series: $scope.symps,
										  data: [{
											x: "Symptoms",
											y: $scope.counts,
											tooltip: "This is a tooltip"
										  }]
										}
										
										
									
									
					$scope.config = {
										  title: 'Patient Count', // chart title. If this is false, no title element will be created.
										  tooltips: true,
										  labels: false, // labels on data points
										  // exposed events
										  mouseover: function() {},
										  mouseout: function() {},
										  click: function() {},
										  // legend config
										  legend: {
											display: true, // can be either 'left' or 'right'.
											position: 'left',
											// you can have html in series name
											htmlEnabled: false
										  },
										  // override this array if you're not happy with default colors
										  colors: [],
										  innerRadius: 0, // Only on pie Charts
										  lineLegend: 'lineEnd', // Only on line Charts
										  lineCurveType: 'cardinal', // change this as per d3 guidelines to avoid smoothline
										  isAnimate: true, // run animations while rendering chart
										  yAxisTickFormat: 's', //refer tickFormats in d3 to edit this value
										  xAxisMaxTicks: 7, // Optional: maximum number of X axis ticks to show if data points exceed this number
										  yAxisTickFormat: 's', // refer tickFormats in d3 to edit this value
										  waitForHeightAndWidth: false // if true, it will not throw an error when the height or width are not defined (e.g. while creating a modal form), and it will be keep watching for valid height and width values
										};
										
				$scope.config1 = {
										  title: 'Patient Count', // chart title. If this is false, no title element will be created.
										  tooltips: true,
										  labels: false, // labels on data points
										  // exposed events
										  mouseover: function() {},
										  mouseout: function() {},
										  click: function() {},
										  // legend config
										  legend: {
											display: true, // can be either 'left' or 'right'.
											position: 'left',
											// you can have html in series name
											htmlEnabled: false
										  },
										  // override this array if you're not happy with default colors
										  colors: [],
										  innerRadius: 0, // Only on pie Charts
										  lineLegend: 'lineEnd', // Only on line Charts
										  lineCurveType: 'cardinal', // change this as per d3 guidelines to avoid smoothline
										  isAnimate: true, // run animations while rendering chart
										  yAxisTickFormat: 's', //refer tickFormats in d3 to edit this value
										  xAxisMaxTicks: 7, // Optional: maximum number of X axis ticks to show if data points exceed this number
										  yAxisTickFormat: 's', // refer tickFormats in d3 to edit this value
										  waitForHeightAndWidth: false // if true, it will not throw an error when the height or width are not defined (e.g. while creating a modal form), and it will be keep watching for valid height and width values
										};						
											
											
										
				   
   
   
	});
  

  
