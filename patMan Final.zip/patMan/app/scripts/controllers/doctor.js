

var app=angular.module('doctorApp',[]);


	
